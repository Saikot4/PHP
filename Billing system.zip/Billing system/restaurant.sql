-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2017 at 04:11 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `restaurant`
--
CREATE DATABASE IF NOT EXISTS `restaurant` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `restaurant`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_dir`
--

CREATE TABLE IF NOT EXISTS `admin_dir` (
  `a_id` int(222) NOT NULL AUTO_INCREMENT,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_dir`
--

INSERT INTO `admin_dir` (`a_id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `c_id` int(222) NOT NULL AUTO_INCREMENT,
  `cname` varchar(222) NOT NULL,
  `cimage` varchar(222) NOT NULL,
  `ctext` text NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `cname`, `cimage`, `ctext`) VALUES
(1, 'veg Burgers', 'download.jpg', 'The patty of a veggie burger may be made from vegetables (like potato or corn), textured vegetable protein (like soy), legumes (beans), tofu, nuts, mushrooms, or grains or seeds\n\n'),
(2, 'Non veg Burgers', 'download (3).jpg', 'NON VEG BURGER\r\nOur range of products include Chicken Burger, Fish Burger, Scrummy Fluffy Egg Burger, Scrummys Special Burger and Scrummys X-Treme Non-Veg Burger.'),
(3, 'Noodels', 'Garlic-Noodles-front.jpg', 'a very thin, long strip of pasta or a similar flour paste, eaten with a sauce or in a soup.\n"cook the noodles in a large pan of boiling water"cook the noodles in a large pan of boiling water"'),
(4, 'Sandwitches', 'maxresdefault.jpg', 'Watch your weight and food you ate.'),
(5, 'Beverages', 'images.jpg', 'Fast things for fast people.'),
(6, 'Tea & Coffee', '5a08510f661aa.jpg', 'tea and coffee here');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(222) NOT NULL AUTO_INCREMENT,
  `name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`) VALUES
(1, 'PRIYA', 'ABC@EMAIL.COM', 'BURGUR'),
(2, 'MANJOT', 'MNNUMEHRA122221@GMAIL.COM', 'SANDWICHES');

-- --------------------------------------------------------

--
-- Table structure for table `daily_update`
--

CREATE TABLE IF NOT EXISTS `daily_update` (
  `id` int(222) NOT NULL AUTO_INCREMENT,
  `name` varchar(222) NOT NULL,
  `image` varchar(222) NOT NULL,
  `text` text NOT NULL,
  `price` varchar(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `daily_update`
--

INSERT INTO `daily_update` (`id`, `name`, `image`, `text`, `price`) VALUES
(1, 'PANCAKE', 'pancake.jfif', 'A tasty burger is what you deserve\r\n', 'Rs.100'),
(2, 'LUNCH DISH', 'lunch.jfif', 'The secret is at the table', 'Rs.169'),
(3, 'WESTREN CUISINE', 'westren food.jfif', 'Big food little money', 'Rs.250');

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE IF NOT EXISTS `detail` (
  `user_id` int(222) NOT NULL AUTO_INCREMENT,
  `fname` varchar(222) NOT NULL,
  `lname` varchar(222) NOT NULL,
  `address` varchar(222) NOT NULL,
  `city` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `brand` varchar(222) NOT NULL,
  `cardno` varchar(222) NOT NULL,
  `emonth` varchar(222) NOT NULL,
  `eyear` varchar(222) NOT NULL,
  `id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`user_id`, `fname`, `lname`, `address`, `city`, `email`, `phone`, `brand`, `cardno`, `emonth`, `eyear`, `id`) VALUES
(17, 'astha', 'ravat', 'abc chonk 12', 'newar badri', 'astha@gmail.com', '345678345', 'Master Card', '4356783452345674', '08 ', '2012 ', 17);

-- --------------------------------------------------------

--
-- Table structure for table `pincode`
--

CREATE TABLE IF NOT EXISTS `pincode` (
  `p_no` int(222) NOT NULL AUTO_INCREMENT,
  `pincode` varchar(222) NOT NULL,
  `place` varchar(222) NOT NULL,
  PRIMARY KEY (`p_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pincode`
--

INSERT INTO `pincode` (`p_no`, `pincode`, `place`) VALUES
(1, '144001', 'Bazar Shahidan'),
(2, '144002', 'Jalandhar City'),
(3, '144003', 'Basti Guzan'),
(4, '144004   ', 'Basti Danishmandan');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE IF NOT EXISTS `sub_category` (
  `id` int(222) NOT NULL AUTO_INCREMENT,
  `image` varchar(222) NOT NULL,
  `name` varchar(222) NOT NULL,
  `text` text NOT NULL,
  `c_id` int(222) NOT NULL,
  `price` int(222) NOT NULL,
  `tax` int(222) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`id`, `image`, `name`, `text`, `c_id`, `price`, `tax`) VALUES
(1, 'download (7).jpg', 'Veggie burger', 'A veggie burger is a burger that does not contain meat. The patty of a veggie burger may be made from soy, legumes, tofu, nuts, mushrooms, or grains or seeds, like wheat and flax.', 1, 45, 22),
(2, 'download (8).jpg', 'Caramel Veggie Burger', 'This delicious veggie burger is a healthy and savory choice for a summer entrée \nThis delicious veggie burger is a healthy and savory choice for a summer entrée and savory choice for a summer entr?e\n\n\n', 1, 60, 44),
(3, 'download (9).jpg', 'Falafel Pita Sauce', ' Recipe for a falafel (fried chickpea balls) stuffed pita sandwich with tomatoes, cucumbers, onions and tahini sauce.stuffed pita sandwich with tomatoes, cucumbers, onions and tahini sauce.', 1, 70, 64),
(4, 'images (3).jpg', 'Grilled Mushroom Burgers', 'mushrooms make a burger that even a meat lover will enjoy!', 1, 40, 55),
(5, 'images (4).jpg', 'Smoked Cheddar and Lentils Burger', 'Serve curried lentil burgers on wholemeal rolls with tomatoes, snow pea shoots and yoghurt for dinner and everyone will be asking for more!', 1, 80, 60),
(6, 'images (5).jpg', ' Portobello and Goat Cheese Burgers', 'To assemble the burger, spread 1-2 tbsp. pesto on the inside of the buns. Then, on the bottom bun, place the patty, followed by about 1 tbsp. goat cheese, and then the sautéed onions and mushrooms', 1, 150, 43),
(7, 'download (10).jpg', 'rosted chicken ', 'Few dishes are as beloved as a golden roast chicken', 2, 89, 32),
(8, 'images (6).jpg', 'cripai rosted burger', 'A definite guy-pleasing burger', 2, 69, 43),
(9, 'bacon sandwich.jfif', 'Bacon sandwitch', 'A bacon sandwich is a sandwich of cooked back bacon between bread that is usually spread with butter, and may be seasoned with ketchup or brown sauce. It is generally served hot', 4, 76, 65),
(10, 'braised with mashroom.jpg', 'BRAISED E-FU NOODLES WITH STRAW MASHROOM', 'TASTE OF HONG KONG...', 3, 80, 65),
(11, 'duckworth.jpg', 'The Duckworth Lewis Burger', 'DELICIOUS NON VEG BURGER', 2, 80, 76),
(12, 'soy-sauce-noodle.jpg', 'soy souce noodle', 'love and olive oil', 3, 65, 34),
(13, 'fried noodles.jfif', 'fried noodles', 'This fried noodles is adapted by variety of food cultures to be served as a westernized Chinese dish.', 3, 75, 54),
(14, 'GRILLED SANDWICH CHEESE.jfif', 'GRILLED CHEESE SANWICHES', 'EAT LIKE YOU ARE ALREADY DEAD...!!!', 4, 50, 75),
(15, 'chocolate fudge soda.jfif', 'chocolate fudge soda', 'A TASTEY DRINK ...', 5, 30, 63),
(16, 'images.jfif', 'FRIED BOLOGNA SLIDERS', 'WELCOME TO DELICIOUS', 4, 65, 65),
(17, 'coke & pepsi.jpg', 'COKE & PEPSI', 'flourish soft drink..!!!', 5, 40, 54),
(18, 'beverage.jfif', 'lemon juice', 'for alcoholic and non alcoholic', 5, 50, 34),
(19, 'coffeee.jpg', 'coffee', 'While nothing can beat a freshly ground cup of coffee in the morning, our hectic schedules mean we might not always have the time. That’s where coffee capsule machines come in. ', 6, 25, 76),
(20, 'cold brew mocha frappe.jpg', 'COLD BREW', 'This 3-ingredient mocha frappe is made with a rich, dark, cold brew coffee, milk "ice cubes," and light chocolate syrup for a simple, healthy, and seriously delicious morning beverage or afternoon...', 6, 30, 45),
(21, 'TEA.jpg', 'GREEN  LEAVES TEA', 'flavour of INDIA', 6, 45, 65);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
