<?php

include("connection/connect.php");

?>

<!DOCTYPE HTML>
<html>
<head>
<title>Rest</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/slider-styles.css" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<link href='http://fonts.googleapis.com/css?family=Libre+Baskerville' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="wrap">
	<div class="top-head">
		<div class="welcome">Welcome To <span>Food Point</span></div>
		<div class="top-nav">
	        <ul>
	            <li class="active"><a href="index.php">Home</a></li>
	            <li><a href="gallery.php">Gallery</a></li>	           
	            <li><a href="#">Login</a></li>
	            <li><a href="contact.php">Contact</a></li>
	        </ul>
	    </div>
	    <div class="clear"> </div>
    </div>
	<div class="header">
	<div class="logo"><a href="index.php"><img src="images/logo.png"  alt="Flowerilla"/></a></div>
    <div class="search">
    	<form>
    		<input type="text" value="" />
    		<input type="submit" value="" />
    	</form>
    </div>
    <div class="clear"> </div>
	</div>
	<div class="nav">
        <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="gallery.php">Gallery</a></li>
           
            <li><a href="contact.php">contact</a></li>
            <div class="clear"> </div>
        </ul>
    </div>
	<div class="main-body">
	<div id="slider">
			<a href="#" target="_blank">
				<img src="images/slider-1.jpg" alt="Mini Ninjas" />
			</a>
			<a href="#" target="_blank">
				<img src="images/slider-2.jpg" alt="Price of Persia" />
			</a>
			<a href="#" target="_blank">
				<img src="images/slider-3.jpg" alt="Price of Persia" />
			</a>
	</div>
	<div class="grids">
		<ul>
			<h4>To day-Items</h4>
			
	<?php	
			$sql="select * from daily_update";
			$result=mysqli_query($db,$sql);
			while($row=mysqli_fetch_array($result))
			{
						$id =  $row['id'];
						$image =  $row['image'];
						$name =  $row['name'];
						$text =  $row['text'];
						$price =  $row['price'];
						
    

	
		echo '<li>
					<h3>'.$name.'</h3>
						<img src="images/'.$row['image'].'"></a>
							<p>'.$text.'</p>
								<button>'.$price.'</button>
			</li>';
			}
		
		?>
		
		
		
		<div class="clear"> </div>
		
		<h4>Menu</h4>
		
		<?php	
			$mql="select * from category";
			$res=mysqli_query($db,$mql);
			while($rows=mysqli_fetch_array($res))
			{
						$cid =  $rows['c_id'];
						$cimage =  $rows['cimage'];
						$cname =  $rows['cname'];
						$ctext =  $rows['ctext'];
						
						
    

	
		echo '<li>
					<h3>'.$cname.'</h3>
						<a href=dishes.php?ext_id='.$rows['c_id'].'><img src="images/'.$rows['cimage'].'"></a>
							<p>'.$ctext.'</p>
								
			</li>';
			}
		
		?>
		

		
		
		
		
		
		<div class="clear"> </div>
		
		
		
		</ul>
		<div class="clear"> </div>
	</div>
	<div class="boxes">
		
		<div class="clear"> </div>
		<ul>
			<li>
			<h3>Restaurants Hours</h3>
			<h4>Breakfast </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
			<h4>Lunch </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
		</li>
		<li>
			<h3>News And Events</h3>
			<p>Festive Recipes for Your Thanksgiving Feast</p>
			<button>Read more</button>
			<h3>Cooking </h3>
			<p>Cooking or cookery is the art, technology and craft of preparing food for consumption with or without the use of heat. Cooking techniques and ingredients vary widely across the world, from grilling food over an open fire to using electric stoves, to baking in various types of ovens, reflecting unique environmental, economic, and cultural traditions and trends. The ways or types of cooking also depend on the skill and type of training an individual cook has. </p>
			
		</li>
		<div class="clear"> </div>
		</ul>
	</div>
	<div class="clear"> </div>
    </div>
</div>
<div class="footer1">
	<div class="wrap">
			<div class="footer-grids">
				<div class="footer-grid1">
					<h3>INFORMATION</h3>
					<ul>
						<li><a href="">Our Store</a></li>
						<li><a href="">Contact Us</a></li>
						<li><a href="">Delivery</a></li>
						<li><a href="">Legal Notice</a></li>
						<li><a href="">About Us</a></li>
					</ul>
				</div>
				<div class="footer-grid1">
					<h3>OUR OFFERS</h3>
					<ul>
						<li><a href="">specials</a></li>
						<li><a href="">New Products</a></li>
						<li><a href="">Top Sellers</a></li>
						<li><a href="">Manufacures</a></li>
						<li><a href="">Suplliers</a></li>
					</ul>
				</div>
				<div class="footer-grid1">
					<h3>YOURACCOUNT</h3>
					<ul>
						<li><a href="">Your Orders</a></li>
						<li><a href="">Your cradit slips</a></li>
						<li><a href="">Your Address</a></li>
						<li><a href="">Your personalinfo</a></li>
						<li><a href="">Your vochers</a></li>
					</ul>
				</div>
				<div class="footer-grid2">
					<h3>FALLOWS US</h3>
					<ul>
						<li><a href=""><img src="images/facebook.png" title="facebook"/></a></li>
						<li><a href=""><img src="images/twitter.png" title="twitter"></a></li>
						<li><a href=""><img src="images/rss.png" title="rss"></a></li>
					</ul>
				</div>
			</div>
			<div class="clear"> </div>
			<div class="copy">
    	<p>&copy; 2013 rights Reseverd </p>
    </div>
    </div>
			<div class="clear">
			</div>
		</div>
<script>
			$('#slider').coinslider();
		</script>

</body>
</html>
