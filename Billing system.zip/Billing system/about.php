
<!DOCTYPE HTML>
<html>
<head>
<title>about</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/slider-styles.css" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<link href='http://fonts.googleapis.com/css?family=Libre+Baskerville' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="wrap">
	<div class="top-head">
		<div class="welcome">Welcome To <span>Food Point</span></div>
		<div class="top-nav">
	        <ul>
	            <li><a href="index.php">Home</a></li>
	            <li><a href="gallery.php">Gallery</a></li>
	           
	            <li><a href="#">Login</a></li>
	            <li><a href="contact.php">Contact</a></li>
	        </ul>
	    </div>
	    <div class="clear"> </div>
    </div>
	<div class="header">
	<div class="logo"><a href="index.php"><img src="images/logo.png"  alt="Flowerilla"/></a></div>
    <div class="search">
    	<form>
    		<input type="text" value="" />
    		<input type="submit" value="" />
    	</form>
    </div>
    <div class="clear"> </div>
	</div>
	<div class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li class="active"><a href="about.php">About</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            
            <li><a href="contact.php">contact</a></li>
            <div class="clear"> </div>
        </ul>
    </div>
	<div class="main-body">
	<div id="slider">
			<a href="#" target="_blank">
				<img src="images/slider-1.jpg" alt="Mini Ninjas" />
			</a>
			<a href="#" target="_blank">
				<img src="images/slider-2.jpg" alt="Price of Persia" />
			</a>
			<a href="#" target="_blank">
				<img src="images/slider-3.jpg" alt="Price of Persia" />
			</a>
	</div>
	<div clas="clear"> </div>
	<div class="grids">
		<ul>
			<h4>ABOUT US</h4>
			
			<p>At Apptopia, we all come to work every day because we want to solve the biggest problem in mobile. Everyone is guessing. Publishers don’t know what apps to build, how to monetize them, or even what to price them at. Advertisers & brands don’t know where their target users are, how to reach them, or even how much they need to spend in order to do so. Investors aren’t sure which apps and genres are growing the quickest, and where users are really spending their time (and money)..</p>
			
			<div class="about-grid1">
				<p>Throughout the history of business, people use data to make more informed decisions. Our mission at Apptopia is to make the app economy more transparent. Today we provide the most actionable mobile app data & insights in the industry. We want to make this data available to as many people as possible (not just the top 5%).</p>
				<img src="images/about-1.jpg" title="img1"/> 
				<div class="clear"> </div>
			</div>
			<div class="about-grid1">
				<p>Cooking Channel is an entertainment brand dedicated to today's passionate food lover. For food people, by food people, Cooking Channel is the answer to a growing hunger for more content devoted to food and cooking in every dimension from global cuisines to international travel, history and unconventional how-to's..</p>
				<img src="images/thumb-8.jpg" title="img1"/> 
				<div class="clear"> </div>
			</div>
			<div class="about-grid1">
				<p>is a unique lifestyle network, website and magazine that connects viewers to the power and joy of food. The network strives to be viewers’ best friend in food and is committed to leading by teaching, inspiring and empowering through its talent and expertise. Food Network is distributed to more than 100 million U.S. households and averages more than 9.9 million unique web users monthly. Since launching in 2009, Food Network Magazine has tripled its rate base and delivers a circulation of 1.4 million. Headquartered in New York, Food Network has a growing international presence with programming in more than 150 countries, including 24 hour networks in Great Britain, India, Asia and Africa. Scripps Networks Interactive (NYSE: SNI), which also owns and operates Cooking Channel (www.cookingchanneltv.com), DIY Network (www.diynetwork.com), Great American Country (www.gactv.com), HGTV (www.hgtv.com), and Travel Channel (www.travelchannel.com), is the manager and general partner.</p>
				<img src="images/about-2.jpg" title="img1"/> 
				<div class="clear"> </div>
			</div>
		<div class="clear"> </div>
		<br>
		<h4>Latest-Items</h4>
		<li>
			<h3>pasta salad</h3>
			<img src="images/pasta salad.jpg">
			<p>Whole Wheat Pasta in Mushroom Sauce. Recipe by Chef Ritu Dalmia. ...</p>
		
		</li>
		<li>
			<h3> Seafood antipasti</h3>
			<img src="images/seafood antipasti salad.jfif">
			<p>Antipasto (plural antipasti) is the traditional first course of a formal Italian meal.</p>
			
		</li>
		<li class="last">
			<h3>Risotto</h3>
			<img src="images/risotto.jpeg">
			<p>Risotto is a northern Italian rice dish cooked in a broth to a creamy consistency. The broth can be derived from meat, fish, or vegetables. Many types of risotto contain butter, wine, and onion.</p>
			
		</li>
			<a href="#">View all</a>
		</ul>
	<div class="clear"> </div>
</div>
	<div class="boxes">
		
		<div class="clear"> </div>
		<ul>
			<li>
			<h3>Restaurants Hours</h3>
			<h4>Breakfast </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
			<h4>Lunch </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
		</li>
		<li>
			<h3>News And Events</h3>
			<p>Get recipes, tips and NYT special offers delivered straight to your inbox. Opt out or contact us anytime</p>
			
			
		</li>
			<div class="clear"> </div>
		</ul>
	</div>
	<div class="clear"> </div>
   </div>
</div>
<div class="footer1">
	<div class="wrap">
			<div class="footer-grids">
				<div class="footer-grid1">
					<h3>INFORMATION</h3>
						<ul>
							<li><a href="">Our Store</a></li>
							<li><a href="">Contact Us</a></li>
							<li><a href="">Delivery</a></li>
							<li><a href="">Legal Notice</a></li>
							<li><a href="">About Us</a></li>
						</ul>
				</div>
				<div class="footer-grid1">
					<h3>OUR OFFERS</h3>
						<ul>
							<li><a href="">specials</a></li>
							<li><a href="">New Products</a></li>
							<li><a href="">Top Sellers</a></li>
							<li><a href="">Manufacures</a></li>
							<li><a href="">Suplliers</a></li>
						</ul>
				</div>
				<div class="footer-grid1">
					<h3>YOURACCOUNT</h3>
						<ul>
							<li><a href="">Your Orders</a></li>
							<li><a href="">Your cradit slips</a></li>
							<li><a href="">Your Address</a></li>
							<li><a href="">Your personalinfo</a></li>
							<li><a href="">Your vochers</a></li>
						</ul>
			</div>
				<div class="footer-grid2">
					<h3>FALLOWS US</h3>
						<ul>
							<li><a href=""><img src="images/facebook.png" title="facebook"/></a></li>
							<li><a href=""><img src="images/twitter.png" title="twitter"></a></li>
							<li><a href=""><img src="images/rss.png" title="rss"></a></li>
						</ul>
				</div>
			</div>
			<div class="clear"> </div>
			<div class="copy">
    	<p>&copy; 2013 rights Reseverd</p>
    </div>
    </div>
			<div class="clear">
			</div>
		</div>
<script>
			$('#slider').coinslider();
		</script>

</body>
</html>
