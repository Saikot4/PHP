<?php
error_reporting(0);
include("connection/connect.php");
$sub_ext_id = $_GET['sub_ext_id'];


	$mql="select * from sub_category where id='$sub_ext_id' ";
			$res=mysqli_query($db,$mql);
			$rows=mysqli_fetch_array($res);
			
						$cid =  $rows['id'];
						$cimage =  $rows['image'];
						$cname =  $rows['name'];
						
						$price =  $rows['price'];
						
						$tax =  $rows['tax'];
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Detail</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/slider-styles.css" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<link href='http://fonts.googleapis.com/css?family=Libre+Baskerville' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="wrap">
	<div class="top-head">
		<div class="welcome">Welcome To <span>Food Point</span></div>
		<div class="top-nav">
	        <ul>
	            <li><a href="index.php">Home</a></li>
	            <li><a href="gallery.php">Gallery</a></li>
	            
	            <li><a href="#">Login</a></li>
	            <li><a href="contact.php">Contact</a></li>
	        </ul>
	    </div>
	    <div class="clear"> </div>
    </div>
	<div class="header">
	<div class="logo"><a href="index.php"><img src="images/logo.png"  alt="Flowerilla"/></a></div>
    <div class="search">
    	<form>
    		<input type="text" value="" />
    		<input type="submit" value="" />
    	</form>
    </div>
    <div class="clear"> </div>
	</div>
	<div class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li ><a href="about.php">About</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="#">Menu</a></li>
            <li><a href="contact.php">contact</a></li>
            <div class="clear"> </div>
        </ul>
    </div>
	<div class="main-body">
	
	<div clas="clear"> </div>
	<div class="grids">
		<ul>
			<h4><?php echo $cname;?></h4>
			<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
			
			
			<div class="about-grid1">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				<img src="images/about-1.jpg" title="img1"/> 
				<div class="clear"> </div>
			</div>
			<div class="about-grid1">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				<img src="images/thumb-8.jpg" title="img1"/> 
				<div class="clear"> </div>
			</div>
			<div class="about-grid1">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
				<img src="images/about-2.jpg" title="img1"/> 
				<div class="clear"> </div>
			</div>
		<div class="clear"> </div>
		<br>
		
	
</div>
	<div class="boxes">
		<div class="order">
		<ul>
			<li>
			<h3>ORDER</h3>
			<h4><?php echo $cname;?></h4>
			<p>Order Price: &nbsp;&nbsp;<span><?php echo $price;?>.00</span></p>

			<p>Sub-Total: &nbsp;&nbsp;<span><span id="output2"><?php echo $price;?>.00</span></p>
			<p>Delivery fee: &nbsp;&nbsp;<span>FREE</span></p>
			<p>tax-include:&nbsp;&nbsp;<span><?php echo $tax;?>.00</span></p>
			<h5>Total:&nbsp;&nbsp;<span><span id="output3"><?php echo $price+$tax;?></span>.00</span></h5>
			<h6><?php echo '<a href=checkout.php?new_id='.$rows['id'].'>Proceed To CheckOut</a>';?></a></h6>
			
		</li>
		</ul>
		</div>
		<div class="clear"> </div>
		<ul>
			<li>
			<h3>Restaurants Hours</h3>
			<h4>Breakfast </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
			<h4>Lunch </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
		</li>
		
			<div class="clear"> </div>
		</ul>
	</div>
	<div class="clear"> </div>
   </div>
</div>
<div class="footer1">
	<div class="wrap">
			<div class="footer-grids">
				<div class="footer-grid1">
					<h3>INFORMATION</h3>
						<ul>
							<li><a href="">Our Store</a></li>
							<li><a href="">Contact Us</a></li>
							<li><a href="">Delivery</a></li>
							<li><a href="">Legal Notice</a></li>
							<li><a href="">About Us</a></li>
						</ul>
				</div>
				<div class="footer-grid1">
					<h3>OUR OFFERS</h3>
						<ul>
							<li><a href="">specials</a></li>
							<li><a href="">New Products</a></li>
							<li><a href="">Top Sellers</a></li>
							<li><a href="">Manufacures</a></li>
							<li><a href="">Suplliers</a></li>
						</ul>
				</div>
				<div class="footer-grid1">
					<h3>YOURACCOUNT</h3>
						<ul>
							<li><a href="">Your Orders</a></li>
							<li><a href="">Your cradit slips</a></li>
							<li><a href="">Your Address</a></li>
							<li><a href="">Your personalinfo</a></li>
							<li><a href="">Your vochers</a></li>
						</ul>
			</div>
				<div class="footer-grid2">
					<h3>FALLOWS US</h3>
						<ul>
							<li><a href=""><img src="images/facebook.png" title="facebook"/></a></li>
							<li><a href=""><img src="images/twitter.png" title="twitter"></a></li>
							<li><a href=""><img src="images/rss.png" title="rss"></a></li>
						</ul>
				</div>
			</div>
			<div class="clear"> </div>
			<div class="copy">
    	<p>&copy; 2013 rights Reseverd </p>
    </div>
    </div>
			<div class="clear">
			</div>
		</div>
<script>

			$('#slider').coinslider();
			

		</script>

</body>
</html>
