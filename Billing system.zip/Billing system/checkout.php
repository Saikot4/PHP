<?php
error_reporting(0);
include("connection/connect.php");
$new_id = $_GET['new_id'];


if(isset($_POST['submit']))                  //if post btn is pressed
{   
$fname = $_POST['fname'];   
$lname = $_POST['lname'];
$address = $_POST['address'];
$city = $_POST['city'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$brand = $_POST['brand'];
$cardno = $_POST['cardno'];
$month = $_POST['exp_month'];
$year = $_POST['exp_year'];
$PINCODE = $_POST['PINCODE'];



                     

	if($fname==' '||$lname==' '||$address==' '||$city==' '||$email==' '||$phone==' '||$brand==' '||$cardno==' '||$month==' '||$year==''||$PINCODE=='' )
	{
	
	         echo  '<div class="alert alert-dismissable fade in" style="background:#ea8f8f;border:1px solid #ce7575;color:#fff;">
                    <a href="#"  data-dismiss="alert" ></a>				
				    All Text Field must be required!
					</div>';	
	
	}
	else
	{
	  
					
	$sql = "INSERT INTO detail(fname,lname,address,city,email,phone,brand,cardno,emonth,eyear,id) VALUES('$fname', '$lname','$address','$city','$email','$phone','$brand','$cardno','$month','$year','$new_id')";
	mysqli_query($db, $sql);
	
	$mql = "select place from pincode where pincode='$PINCODE'";
	$res=mysqli_query($db,$mql);
			$rows=mysqli_fetch_array($res);
	 $place=$rows['place'];
					
	
    
	if($PINCODE=='144001')
	{
		echo' <div class="alert alert-success alert-dismissable fade in">
          <a href="#" data-dismiss="alert" ></a>
		 	Your Order is placed.coorier Boy Reached with in  just 45 Minutes at ('.$place.').
			</div>';
	}
	elseif($PINCODE=='144002')
		{
			echo' <div class="alert alert-success alert-dismissable fade in">
          <a href="#" data-dismiss="alert" ></a>
		 	Your Order is placed.coorier Boy Reached with in  just 40 Minutes at ('.$place.').
			</div>';
		}
		elseif($PINCODE=='144003')
		{
			echo' <div class="alert alert-success alert-dismissable fade in">
          <a href="#" data-dismiss="alert" ></a>
		 	Your Order is placed.coorier Boy Reached with in just 20 Minutes at ('.$place.').
			</div>';
		}
		elseif($PINCODE=='144004')
		{
			echo' <div class="alert alert-success alert-dismissable fade in">
          <a href="#" data-dismiss="alert" ></a>
		 	Your Order is placed.coorier Boy Reached with  in  just 25 Minutes at ('.$place.').
			</div>';
		}
		else
		{
			echo' <div class="alert alert-success alert-dismissable fade in">
          <a href="#" data-dismiss="alert" ></a>
		 	Your Order is placed.coorier Boy Reached with in  just 30 Minutes.
			</div>';
		}
	
	}
	
	
}



	$mql="select * from sub_category where id='$new_id' ";
			$res=mysqli_query($db,$mql);
			$rows=mysqli_fetch_array($res);
			
						$cid =  $rows['id'];
						$cimage =  $rows['image'];
						$cname =  $rows['name'];
						
						$price =  $rows['price'];
							
						$tax =  $rows['tax'];
?>
<!DOCTYPE HTML>
<html>
<head>
<title> checkout</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/slider-styles.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/popup.php"  />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-migrate-3.0.0.js"></script>




<script type="text/javascript" src="js/slider.js"></script>

<link href='http://fonts.googleapis.com/css?family=Libre+Baskerville' rel='stylesheet' type='text/css'>

</head>
<body>
<div class="wrap">
	<div class="top-head">
		<div class="welcome">Welcome To <span>Food Point</span></div>
		<div class="top-nav">
	        <ul>
	            <li><a href="index.php">Home</a></li>
	            <li><a href="gallery.php">Gallery</a></li>
	           
	            <li><a href="#">Login</a></li>
	            <li class="active"><a href="contact.php">Contact</a></li>
	        </ul>
	    </div>
	    <div class="clear"> </div>
    </div>
	<div class="header">
	<div class="logo"><a href="index.php"><img src="images/logo.png"  alt="Flowerilla"/></a></div>
    <div class="search">
    	<form>
    		<input type="text" value="" />
    		<input type="submit" value="" />
    	</form>
    </div>
    <div class="clear"> </div>
	</div>
	<div class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="gallery.php">Gallery</a></li>
           
            <li ><a href="contact.php">contact</a></li>
            <div class="clear"> </div>
        </ul>
    </div>
	<div class="main-body">
	
	
	<div class="order">
		<ul>
			<li>
			<h3><?php echo $cname;?></h3>
			
			<p>Order Price: &nbsp;&nbsp;<span><?php echo $price;?>.00</span></p>
			<p>Quantity: &nbsp;&nbsp;<span>x<span id="output">1</span>&nbsp;&nbsp;&nbsp;&nbsp;<button id="target" type="button">Click</button>
				</p>
			<p>Sub-Total: &nbsp;&nbsp;<span><span id="output2"><?php echo $price;?>.00</span></p>
			<p>Delivery fee: &nbsp;&nbsp;<span>FREE</span></p>
			<p>tax-include:&nbsp;&nbsp;<span>Rs.<?php echo $tax;?>.00</span></p>
			<h3 style='float:right;'>Total:&nbsp;&nbsp;<span><span id="output3"><?php echo $price+$tax;?></span>.00</span></h3>
			
			
			 
			
		</li>
		</ul>
		</div>
  

		 
	<div class="feed">
	<div class="feedback">
       
    <form action='' method='post'>
        <div>
            	<span><label>first-Name</label></span>
            	<span><input style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''  pattern="[a-z A-Z]*"  name='fname' type="text" placeholder='enter your first name' /></span>
            </div>
            <div>
            	<span><label>Email</label></span>
            	<span><input style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''   pattern="[a-z A-Z]*"  name='email' type="email" placeholder='enter your email'  /></span>
            </div>
        	<div>
            	<span><label>Address</label></span>
            	<span>
				
				<textarea style='width:400px;
									   height:100px;
									   padding:5px;
									   font-size:16px;
									   background:#eee;
									   box-shadow: 0 0 6px #aaa;
									   border:none;
									   font-size:16px;
									   color:#333;
									   outline: none;
								       resize: none;
									   font-family: 'Istok Web', sans-serif;''  pattern="[a-z A-Z]*" name='address' placeholder='enter your address' ></textarea></span>
				</div>
				
				
        	<div>
            	<span><label>Card Type</label></span>
            	<span><select style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''  name='brand'  >
								
								<option value='abc' selected disabled >------------------SELECT CARD TYPE------------------</option>	
								
                                                  <option value='Master Card'>Master Card</option>
                                                  <option value='Visa'>Visa</option>
                                                  <option value='Discover'>Discover</option>
												   <option value='American Express'>American Express</option>
									
									</select></span>
            </div>
        	
			<div>
            	<span><label>Expiry Month</label></span>
            	<span><select style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''   name='exp_month'>
								
								<option value='abc' selected disabled >------------------SELECT EXPIRY MONTH------------------</option>	
								 <option value='01 '>01</option>
												    <option value='02 '>02</option>
													  <option value='03 '>03</option>
													    <option value='05 '>05</option>
														    <option value='07 '>07</option>
															  <option value='08 '>08</option>
															    <option value='09 '>09</option>
																<option value='10 '>10</option>
																<option value='11 '>11</option>
																<option value='12 '>12</option>
									
									</select></span>
            </div>
			 <div>
            	<span><label>PINCODE</label></span>
            	<span><input style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''  pattern="[0-9]*"  name='PINCODE' type="text" placeholder='enter Area PINCODE' /></span>
            </div>
			
			
			
       
    </div>
	
	
    <div class="feedback" style='float:right;'>
      
        
        	<div>
            	<span><label>Last-Name</label></span>
            	<span><input style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''  pattern="[a-z A-Z]*" name='lname'  type="text" placeholder='enter your last name'  /></span>
            </div>
            <div>
            	<span><label>Phone</label></span>
            	<span><input style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''  pattern="[0-9]*"  name='phone' type="text" placeholder='enter your phone No.'  /></span>
            </div>
        	<div>
            	<span><label>Street Address</label></span>
            	<span><textarea style='width:400px;
									   height:100px;
									   padding:5px;
									   font-size:16px;
									   background:#eee;
									   box-shadow: 0 0 6px #aaa;
									   border:none;
									   font-size:16px;
									   color:#333;
									   outline: none;
								       resize: none;
									   font-family: 'Istok Web', sans-serif;''  pattern="[a-z A-Z]*" name='city' placeholder='enter street address' ></textarea></span>
            </div>
        	 <div>
            	<span><label>Card No.</label></span>
            	<span><input style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;''  pattern="[0-9]*"  name='cardno' type="text" placeholder='enter your Card No.' /></span>
            </div>
			
			<div>
            	<span><label>Expiry YEAR</label></span>
            	<span><select style='width:400px;
									padding:8px;
									font-size:16px;
									color:#333;
									background:#eee;
									box-shadow: 0 0 6px #aaa;
									border:none;
									outline: none;
									font-family: 'Istok Web', sans-serif;'' name='exp_year' >
								
								<option value='abc' selected disabled >------------------SELECT EXPIRY YEAR------------------</option>	
								  <option value='2018'>2018</option>
												    <option value='2017 '>2017</option>
													  <option value='2016 '>2016</option>
													    <option value='2015 '>2015</option>
														  <option value='2014 '>2014</option>
														    <option value='2013 '>2013</option>
															  <option value='2012 '>2012</option>
															    <option value='2011 '>2011</option>
																<option value='2010 '>2010</option>
									
									</select></span>
            </div>
			
			<div>
            	<span><input type="submit" value="PAY-NOW"  name='submit' style='float:right;'/></span>
            </div>
        </form>
    </div>
	
    <div class="clear"></div>
</div>
</div>
	<div class="clear"> </div>
    </div>
<div class="footer1">
	<div class="wrap">
			<div class="footer-grids">
				<div class="footer-grid1">
					<h3>INFORMATION</h3>
					<ul>
						<li><a href="">Our Store</a></li>
						<li><a href="">Contact Us</a></li>
						<li><a href="">Delivery</a></li>
						<li><a href="">Legal Notice</a></li>
						<li><a href="">About Us</a></li>
					</ul>
			   </div>
				<div class="footer-grid1">
					<h3>OUR OFFERS</h3>
					<ul>
						<li><a href="">specials</a></li>
						<li><a href="">New Products</a></li>
						<li><a href="">Top Sellers</a></li>
						<li><a href="">Manufacures</a></li>
						<li><a href="">Suplliers</a></li>
					</ul>
			</div>
				<div class="footer-grid1">
					<h3>YOURACCOUNT</h3>
					<ul>
						<li><a href="">Your Orders</a></li>
						<li><a href="">Your cradit slips</a></li>
						<li><a href="">Your Address</a></li>
						<li><a href="">Your personalinfo</a></li>
						<li><a href="">Your vochers</a></li>
					</ul>
				</div>
				<div class="footer-grid2">
					<h3>FALLOWS US</h3>
					<ul>
						<li><a href=""><img src="images/facebook.png" title="facebook"/></a></li>
						<li><a href=""><img src="images/twitter.png" title="twitter"></a></li>
						<li><a href=""><img src="images/rss.png" title="rss"></a></li>
						
					</ul>
				</div>
			</div>
			<div class="clear"> </div>
			<div class="copy">
    	<p>&copy; 2013 rights Reseverd</p>
    </div>
    </div>
			<div class="clear">
			</div>
		</div>

<script type="text/javascript">
var vals = <?php echo $price;?>;
			$('#slider').coinslider();
			
			$('#target').click(function() {
    $('#output').html(function(i, val) { return val*1+1 });
	$('#output2').html(function(i, val) { return val*1+vals });
	$('#output3').html(function(i, val) { return val*1+vals });
});


</script>

</body>
</html>
