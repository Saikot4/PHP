
<!DOCTYPE HTML>
<html>
<head>
<title>gallary</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Libre+Baskerville' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery1.js"></script>
<script type="text/javascript" src="js/jquery.lightbox.js"></script>
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen" />
  <script type="text/javascript">
    $(function() {
        $('.gallery a').lightBox();
    });
    </script>
</head>
<body>
<div class="wrap">
	<div class="top-head">
		<div class="welcome">Welcome To <span>Food Point</span></div>
		<div class="top-nav">
	        <ul>
	            <li><a href="index.php">Home</a></li>
	            <li class="active"><a href="gallery.php">Gallery</a></li>

	            <li><a href="#">Login</a></li>
	            <li><a href="contact.php">Contact</a></li>
	        </ul>
	    </div>
	    <div class="clear"> </div>
    </div>
	<div class="header">
	<div class="logo"><a href="index.php"><img src="images/logo.png"  alt="Flowerilla"/></a></div>
    <div class="search">
    	<form>
    		<input type="text" value="" />
    		<input type="submit" value="" />
    	</form>
    </div>
    <div class="clear"> </div>
	</div>
	<div class="nav">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li class="active"><a href="gallery.php">Gallery</a></li>
           
            <li><a href="contact.php">contact</a></li>
            <div class="clear"> </div>
        </ul>
    </div>
	<div class="main-body">
	<div class="grids">
		<div class="gallery">
			<ul>
					<li><a href="images/g1.jpg"><img src="images/g1.jpg" alt="" /></a></li>
					<li><a href="images/g2.jpg"><img src="images/g2.jpg" alt="" /></a></li>
					<li><a href="images/g3.jpg"><img src="images/g3.jpg" alt="" /></a></li>
					<li><a href="images/g4.jpg"><img src="images/g4.jpg" alt="" /></a></li>
					<li><a href="images/g5.jpg"><img src="images/g5.jpg" alt="" /></a></li>
					<li><a href="images/g6.jpg"><img src="images/g6.jpg" alt="" /></a></li>
					<li><a href="images/g7.jpg"><img src="images/g7.jpg" alt="" /></a></li>
					<li><a href="images/g8.jpg"><img src="images/g8.jpg" alt="" /></a></li>
					<li><a href="images/g9.jpg"><img src="images/g9.jpg" alt="" /></a></li>
					<li><a href="images/g10.jpg"><img src="images/g10.jpg" alt="" /></a></li>
					<li><a href="images/g11.jpg"><img src="images/g11.jpg" alt="" /></a></li>
					<li><a href="images/g12.jpg"><img src="images/g12.jpg" alt="" /></a></li>
					<li><a href="images/g13.jpg"><img src="images/g13.jpg" alt="" /></a></li>
					<li><a href="images/g14.jpg"><img src="images/g14.jpg" alt="" /></a></li>
					<li><a href="images/g1.jpg"><img src="images/g1.jpg" alt="" /></a></li>
				<div class="clear"></div></ul>
		</div>
	<div class="clear"> </div>
	</div>
	<div class="boxes">
	
		<div class="clear"> </div>
		<ul>
			<li>
			<h3>Restaurants Hours</h3>
			<h4>Breakfast </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
			<h4>Lunch </h4>
			<p>Monday - Friday &nbsp;&nbsp; 11 am - 03 pm</p>
			<p>Saturaday - Sunday &nbsp;&nbsp; 11 am - 04 pm</p>
		</li>
		<li>
			<h3>News And Events</h3>
			<p>Festive reciepe for your thanksgiving feast...</p>
			<button>Read more</button>
			<h3>dishes</h3>
			<p> Cooking is done both by people in their own dwellings and by professional cooks and chefs in restaurants and other food establishments.</p>
			<button>Read more</button>
		</li>
		<div class="clear"> </div>
		</ul>
	</div>
	<div class="clear"> </div>
    </div>
</div>
<div class="footer1">
	<div class="wrap">
			<div class="footer-grids">
				<div class="footer-grid1">
					<h3>INFORMATION</h3>
					<ul>
						<li><a href="">Our Store</a></li>
						<li><a href="">Contact Us</a></li>
						<li><a href="">Delivery</a></li>
						<li><a href="">Legal Notice</a></li>
						<li><a href="">About Us</a></li>
					</ul>
				</div>
				<div class="footer-grid1">
					<h3>OUR OFFERS</h3>
					<ul>
						<li><a href="">specials</a></li>
						<li><a href="">New Products</a></li>
						<li><a href="">Top Sellers</a></li>
						<li><a href="">Manufacures</a></li>
						<li><a href="">Suplliers</a></li>
					</ul>
				</div>
				<div class="footer-grid1">
					<h3>YOURACCOUNT</h3>
					<ul>
						<li><a href="">Your Orders</a></li>
						<li><a href="">Your cradit slips</a></li>
						<li><a href="">Your Address</a></li>
						<li><a href="">Your personalinfo</a></li>
						<li><a href="">Your vochers</a></li>
					</ul>
				</div>
				<div class="footer-grid2">
					<h3>FALLOWS US</h3>
					<ul>
						<li><a href=""><img src="images/facebook.png" title="facebook"/></a></li>
						<li><a href=""><img src="images/twitter.png" title="twitter"></a></li>
						<li><a href=""><img src="images/rss.png" title="rss"></a></li>
					</ul>
			</div>
			</div>
			<div class="clear"> </div>
			<div class="copy">
    	<p>&copy; 2013 rights Reseverd</p>
    </div>
    </div>
			<div class="clear">
			</div>
		</div>
<script>
			$('#slider').coinslider();
		</script>

</body>
</html>
