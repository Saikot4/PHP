<?php
error_reporting(0);
include("../connection/connect.php");



if(isset($_POST['submit']) )          //if upload btn is pressed
{
	
	
	
$cName=$_POST['cName'];
$text=$_POST['text'];
$price=$_POST['price'];
$subcategory=$_POST['subcategory'];
$tax=$_POST['tax'];
	
	
  
        $validextensions = array("jpeg", "jpg", "png");  //Extensions which are allowed
		$fname = $_FILES['file']['name'];
        $ext = explode('.',$fname);//explode file name from dot(.) 
        $ext = strtolower(end($ext)); //store extensions in the variable
        
		$fnew =uniqid().'.'.$ext;//set the target path with a new name of image
		
		$store = "../images/".basename($fnew);      
		
        
	  if(($_FILES["file"]["size"] < 3000000) && in_array($ext, $validextensions))
	  {
					 $sql = "INSERT INTO sub_category(image,name,text,c_id,price,tax) VALUES('$fnew','$cName','$text','$subcategory','$price','$tax')";          // store the submited data ino the database :images
	                  mysqli_query($db, $sql); 
                       
						move_uploaded_file($_FILES['file']['tmp_name'], $store);//if file moved to uploads folder
						$success= '<p class="info" id="success"><span class="info_inner">sub-Category Added Successfully.</span></p>';
	  }	
	  else
	  {
		  
		 $error = '<p class="info" id="error"><span class="info_inner">Invalid size and Invalid Extention!</span></p>';
		  
		  
	  }
					  
				
				   	
					
              
     
}



	
	
	




?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dashboard | Modern Admin</title>
<link rel="stylesheet" type="text/css" href="css/960.css" />
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/text.css" />
<link rel="stylesheet" type="text/css" href="css/blue.css" />
<link type="text/css" href="css/smoothness/ui.css" rel="stylesheet" />  
    <script type="text/javascript" src="../../ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
    <script type="text/javascript" src="js/blend/jquery.blend.js"></script>
	<script type="text/javascript" src="js/ui.core.js"></script>
	<script type="text/javascript" src="js/ui.sortable.js"></script>    
    <script type="text/javascript" src="js/ui.dialog.js"></script>
    <script type="text/javascript" src="js/ui.datepicker.js"></script>
    <script type="text/javascript" src="js/effects.js"></script>
    <script type="text/javascript" src="js/flot/jquery.flot.pack.js"></script>
    <!--[if IE]>
    <script language="javascript" type="text/javascript" src="js/flot/excanvas.pack.js"></script>
    <![endif]-->
	<!--[if IE 6]>
	<link rel="stylesheet" type="text/css" href="css/iefix.css" />
	<script src="js/pngfix.js"></script>
    <script>
        DD_belatedPNG.fix('#menu ul li a span span');
    </script>        
    <![endif]-->
    <script id="source" language="javascript" type="text/javascript" src="js/graphs.js"></script>

</head>

<body>
<!-- WRAPPER START -->
<div class="container_16" id="wrapper">	
<!-- HIDDEN COLOR CHANGER -->      
     
  	<!--LOGO-->
	<div class="grid_8" id="logo"> Administration</div>
    <div class="grid_8">
<!-- USER TOOLS START -->
      <div id="user_tools"><span>  <a href="#">Logout</a></span></div>
    </div>
<!-- USER TOOLS END -->    
<div class="grid_16" id="header">
<!-- MENU START -->
<div id="menu">
	<ul class="group" id="menu_group_main">
		<li class="item first" id="one"><a href="dashboard.php" class="main "><span class="outer"><span class="inner dashboard">Dashboard</span></span></a></li>
        <li class="item middle" id="two"><a href="view_category.php" class="main "><span class="outer"><span class="inner content">Categories</span></span></a></li>
           <li class="item middle" id="two"><a href="view_subcategory.php" class="main current"><span class="outer"><span class="inner content">Sub-Categories</span></span></a></li>
                 
    </ul>
</div>
<!-- MENU END -->
</div>
<div class="grid_16">
<!-- TABS START -->
    <div id="tabs">
         <div class="container">
            <ul>
                      <li><a href="view_subcategory.php" ><span>view Sub-Category</span></a></li>
					     <li><a href="add_subcategory.php" class="current"><span>add Sub-Category</span></a></li>
                            
           </ul>
        </div>
    </div>
<!-- TABS END -->    
</div>
<!-- HIDDEN SUBMENU START -->


	
	
	
	
	
	<!--  SECOND SORTABLE COLUMN END -->
    <div class="clear"></div>
    <!--THIS IS A WIDE PORTLET-->
      <!--THIS IS A PORTLET-->
        <div class="portlet">
		<div class="portlet-header">Add sub-Categories</div>

		<div class="portlet-content">
		 <?php
		   echo $success;
		   echo $error;
		   ?>
		   <center><p>You can Add sub-Categories here on the bases of Images add Category name to assign categories.
		  
		   </p>
		   
		   
		  <h3>Sub-Categories</h3>
		 <form id="form1"  method="post" action="" enctype="multipart/form-data">
		  <label>Select Category Name</label>
<?php
			
		                     echo " <select name='subcategory' id='textfield' class='smallInput'>
							                  <option value=''><i>  ------- Choose category ---------</i></option>";
							  
                               $jql = "SELECT * FROM category ";
							   $last=mysqli_query($db, $jql);
							   while($field = mysqli_fetch_array($last))
								{
							        echo		"<option value=".$field['c_id'].">".$field['cname']."</option>";
								}	
							        echo		"</select>";
?>	
		 
		 
		 
		 
		    <label>Sub-Category Name</label>
		     <input type="text" name="cName" id="textfield" class="smallInput"  />
			<label>Choose Image</label>
            <input type="file" name="file" id="textfield2" class="largeInput" />
			 <label>Sub-Category Price</label>
		     <input type="text" name="price" id="textfield" class="smallInput"  />
			
            <label>About Sub-Category</label>
		    <textarea name="text" cols="45" rows="3" class="smallInput" id="textarea"></textarea>
           
		   <label>Add TAX</label>
		     <input type="text" name="tax" id="textfield" class="smallInput"  />
			
			<input style="margin-left:430px;width:80px;border-radius:5px;border-left:1px solid #3977a6;" class="button" type="submit" name="submit"  ></input>
		  </form></center>
		  <p>&nbsp;</p>
		</div>
        </div>
      </div>
    <div class="clear"> </div>
<!-- END CONTENT-->    
  </div>
<div class="clear"> </div>

		<!-- This contains the hidden content for modal box calls -->
		<div class='hidden'>
			<div id="inline_example1" title="This is a modal box" style='padding:10px; background:#fff;'>
			<p><strong>This content comes from a hidden element on this page.</strong></p>
            			
			<p><strong>Try testing yourself!</strong></p>
            <p>You can call as many dialogs you want with jQuery UI.</p>
			</div>
		</div>
</div>
<!-- WRAPPER END -->
<!-- FOOTER START -->
<div class="container_16" id="footer">
Website Administration  <a href="../index.htm">All right recived</a></div>
<!-- FOOTER END -->
</body>
</html>
